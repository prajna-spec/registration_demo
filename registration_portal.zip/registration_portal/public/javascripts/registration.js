function submit()
{


   var gender;
        if(document.getElementById("Male").checked){
              gender = document.getElementById("Male").value;

          }
          else if(document.getElementById("Female").checked)
          {
              gender = document.getElementById("Female").value;
          }


    let userInfo = {


        user: document.getElementById("Name").value,


        email: document.getElementById("Email").value,
        mobile_num:document.getElementById("Phone").value
        type:gender



    };



    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function(){
        if(this.status==200){
           alert("You are successfully registered");
        } else if (this.readyState==4 && this.status>=400){
            alert("Sign Up Failed");
         
        }
    };


    xmlhttp.open("POST","/submit",true);
    xmlhttp.setRequestHeader("Content-type","application/json");
    xmlhttp.send(JSON.stringify(userInfo));


}


