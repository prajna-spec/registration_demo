var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});
module.exports = router;
router.post('/submit', function(req,res,next){

    if('user' in req.body &&

    'email' in req.body &&
    'mobile_num' in req.body &&
    `type` in req.body)


    {
        req.pool.getConnection(function(err,connection){
            if(err){
                res.sendStatus(500);
                return;
            }
            var query = `INSERT INTO Users (user,email,mobile_num,type)
                            VALUES (?,?,?,?);`;
            connection.query(query,[
                req.body.user,
                req.body.email,
                req.body.mobile_num,
                req.body.gender

                ], function(err,rows,fields){
                connection.release();
                if(err){
                    res.sendStatus(500);
                    return;
                } if(rows.length>0){
                        req.session.user = rows[0];
                        res.json(rows[0]);
                } else {
                    res.sendStatus(401);
                }
            });
        });
    } else {
        res.sendStatus(400);
    }

});




